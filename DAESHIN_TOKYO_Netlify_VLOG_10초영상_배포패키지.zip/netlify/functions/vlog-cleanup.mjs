// Removes abandoned multipart uploads, not published stories.
import { getStore } from '@netlify/blobs';
export const config = { schedule: '@daily' };
export default async function handler() {
  const posts=getStore({name:'dtokyo-vlog-posts',consistency:'strong'});
  const media=getStore({name:'dtokyo-vlog-media',consistency:'strong'});
  const list=await posts.list({prefix:'pending/'});
  let cleaned=0;
  for(const entry of list.blobs.slice(0,300)){
    const manifest=await posts.get(entry.key,{type:'json',consistency:'strong'});
    if(!manifest || Date.now()-new Date(manifest.created_at).getTime()<2*3600*1000)continue;
    const chunks=(await media.list({prefix:`chunks/${manifest.id}/`})).blobs;
    await Promise.all(chunks.map(({key})=>media.delete(key)));
    await posts.delete(entry.key);cleaned++;
  }
  console.log('DAESHIN VLOG abandoned uploads cleaned',cleaned);
  return new Response(null,{status:204});
}
