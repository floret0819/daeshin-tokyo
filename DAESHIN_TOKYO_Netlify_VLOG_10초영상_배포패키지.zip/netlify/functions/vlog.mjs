import { getStore } from '@netlify/blobs';
import { randomUUID, createHash, createHmac, timingSafeEqual } from 'node:crypto';

const MAX_IMAGE = 8 * 1024 * 1024;
const MAX_VIDEO = 12 * 1024 * 1024;
const PART_SIZE = 1536 * 1024;
const MAX_PARTS = Math.ceil(MAX_VIDEO / PART_SIZE);
const ONE_DAY = 86400000;
const ID_RE = /^[0-9a-f]{8}-[0-9a-f-]{27,36}$/i;
const DEVICE_RE = /^[0-9a-f-]{36}$/i;
const MIME = new Set(['image/jpeg', 'image/png', 'image/webp', 'video/mp4', 'video/webm']);
const json = (body, status=200, headers={}) => Response.json(body, {status, headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...headers}});
const fail=(message,status=400)=>json({error:message},status);
const files=()=>getStore({name:'dtokyo-vlog-media', consistency:'strong'});
const meta=()=>getStore({name:'dtokyo-vlog-posts', consistency:'strong'});
const social=()=>getStore({name:'dtokyo-vlog-activity', consistency:'strong'});
const getIp=(req)=>req.headers.get('x-nf-client-connection-ip')||req.headers.get('x-forwarded-for')?.split(',')[0]?.trim()||'unknown';
const hash=value=>createHash('sha256').update(String(value)).digest('hex');
const secrets=()=>({password:process.env.VLOG_ADMIN_PASSWORD||'',email:(process.env.VLOG_ADMIN_EMAIL||'').toLowerCase().trim(),secret:process.env.VLOG_SESSION_SECRET||''});
const adminReady=()=>{const s=secrets();return s.password.length>=12&&s.secret.length>=32&&!!s.email};
const sign=(contents,secret)=>createHmac('sha256',secret).update(contents).digest('hex');
const same=(a,b)=>{const x=Buffer.from(String(a)),y=Buffer.from(String(b));return x.length===y.length&&timingSafeEqual(x,y)};
const generateToken=(value,seconds,secret)=>{const data=value+'.'+Math.floor(Date.now()/1000+seconds);return data+'.'+sign(data,secret)};
const verifyToken=(token,secret,prefix)=>{if(!secret||!token||token.length>500)return false;const t=token.split('.');if(t.length!==3||t[0]!==prefix||!/^[0-9]+$/.test(t[1])||Number(t[1])<Date.now()/1000)return false;return same(t[2],sign(t.slice(0,2).join('.'),secret))};
const adminAuthed=req=>verifyToken(req.headers.get('authorization')?.replace(/^Bearer\s+/i,'')||'',secrets().secret,'admin');
const tokenForUpload=id=>generateToken('upload-'+id,60*30,secretUpload());
// Per-site storage secret is never included in client JS. Configure VLOG_SESSION_SECRET on Netlify before starting uploads.
const secretUpload=()=>secrets().secret;
const uploadAuthorized=(req,id)=>verifyToken(req.headers.get('x-upload-token')||'',secretUpload(),'upload-'+id);
const validId=x=>ID_RE.test(String(x||''));
const validDevice=x=>DEVICE_RE.test(String(x||''));
const readJSON=async(req)=>{const text=await req.text();if(text.length>16000)throw Error('요청이 너무 큽니다.');return JSON.parse(text||'{}')};
const validStory=async id=>validId(id)?meta().get('stories/'+id,{type:'json',consistency:'strong'}):null;
const parseSort=(a,b)=>b.created_at.localeCompare(a.created_at);
const imageMatches=(mime,buf)=>{
 if(mime==='image/jpeg')return buf[0]===0xff&&buf[1]===0xd8&&buf[2]===0xff;
 if(mime==='image/png')return Buffer.from(buf.subarray(0,8)).equals(Buffer.from([137,80,78,71,13,10,26,10]));
 if(mime==='image/webp')return Buffer.from(buf.subarray(0,4)).toString()==='RIFF'&&Buffer.from(buf.subarray(8,12)).toString()==='WEBP';
 if(mime==='video/mp4')return Buffer.from(buf.subarray(4,8)).toString()==='ftyp';
 if(mime==='video/webm')return Buffer.from(buf.subarray(0,4)).equals(Buffer.from([0x1a,0x45,0xdf,0xa3]));
 return false;
};
const countPrefix=async(store,prefix)=> (await store.list({prefix})).blobs.length;

async function feed(url) {
 const offset=Math.max(0,Math.min(3000,Number(url.searchParams.get('offset'))||0));
 const limit=Math.max(1,Math.min(121,Number(url.searchParams.get('limit'))||121));
 const device=url.searchParams.get('device');
 const store=meta();
 const keys=(await store.list({prefix:'stories/'})).blobs.map(x=>x.key).sort().reverse().slice(offset,offset+limit);
 const posts=(await Promise.all(keys.map(k=>store.get(k,{type:'json',consistency:'strong'})))).filter(Boolean).sort(parseSort);
 const keysLiked=(await social().list({prefix:'likes/'})).blobs.map(x=>x.key);
 const counts=new Map();const liked=new Set();const keyForDevice=validDevice(device)?hash(device):'';
 for(const key of keysLiked){const parts=key.split('/');if(parts.length!==3)continue;counts.set(parts[1],(counts.get(parts[1])||0)+1);if(keyForDevice&&parts[2]===keyForDevice)liked.add(parts[1]);}
 return json(posts.map(p=>({...p,like_count:counts.get(p.id)||0,liked:liked.has(p.id)})));
}

async function start(req){
 if(!secrets().secret||secrets().secret.length<32)return fail('Netlify에 VLOG_SESSION_SECRET을 먼저 등록해 주세요.',503);
 const data=await readJSON(req), mime=String(data.mime||''), size=Number(data.size), klass=Number(data.class_number), device=String(data.device||'');
 if(!MIME.has(mime))return fail('지원하지 않는 사진·영상 형식입니다.');
 if(!Number.isSafeInteger(size)||size<1||size>(mime.startsWith('video/')?MAX_VIDEO:MAX_IMAGE))return fail('파일 용량 제한을 초과했습니다. (사진 8MB / 영상 12MB)');
 if(!Number.isInteger(klass)||klass<1||klass>10||!validDevice(device))return fail('반 또는 기기 식별 정보가 올바르지 않습니다.');
 const duration=Number(data.duration||0);
 if(mime.startsWith('video/')&&(!Number.isFinite(duration)||duration<=0||duration>10.3))return fail('10초를 초과하는 영상은 올릴 수 없습니다.');
 const cap=String(data.caption||'').trim().slice(0,90);
 // Lightweight abuse guard: account-free upload is never fully abuse-proof.
 const ip=hash(getIp(req)).slice(0,28), time=new Date().toISOString().slice(0,10), store=social();
 if(await countPrefix(store,`upload-limits/${time}/${ip}/`)>=500)return fail('오늘 이 네트워크의 업로드 횟수를 초과했습니다.',429);
 if(await countPrefix(store,`device-limits/${time}/${hash(device)}/`)>=15)return fail('오늘 업로드 횟수를 초과했습니다.',429);
 const id=randomUUID(), parts=Math.ceil(size/PART_SIZE);
 const manifest={id,class_number:klass,mime_type:mime,caption:cap,size,parts,created_at:new Date().toISOString(),device_hash:hash(device),partSize:PART_SIZE};
 await meta().setJSON('pending/'+id,manifest);
 await store.set(`upload-limits/${time}/${ip}/${id}`,'1');
 await store.set(`device-limits/${time}/${hash(device)}/${id}`,'1');
 return json({id,parts,part_size:PART_SIZE,token:tokenForUpload(id),max_video_seconds:10});
}
async function part(req,url){
 const id=url.searchParams.get('id'), index=Number(url.searchParams.get('index'));
 if(!validId(id)||!uploadAuthorized(req,id))return fail('업로드 권한이 만료되었습니다.',403);
 const entry=await meta().get('pending/'+id,{type:'json'});
 if(!entry||Date.now()-new Date(entry.created_at).getTime()>30*60000)return fail('업로드 요청이 만료됐습니다.',410);
 if(!Number.isInteger(index)||index<0||index>=entry.parts)return fail('잘못된 영상 조각 번호입니다.');
 const bytes=new Uint8Array(await req.arrayBuffer());
 const expected=index===entry.parts-1?entry.size-(index*PART_SIZE):PART_SIZE;
 if(bytes.length!==expected)return fail('전송된 파일 크기가 올바르지 않습니다.');
 if(index===0&&!imageMatches(entry.mime_type,bytes))return fail('파일 내용과 형식이 일치하지 않습니다.');
 await files().set(`chunks/${id}/${String(index).padStart(3,'0')}`,bytes.buffer);
 return json({ok:true,index});
}
async function finish(req){
 const data=await readJSON(req), id=data.id;
 if(!validId(id)||!uploadAuthorized(req,id))return fail('업로드 권한이 없습니다.',403);
 const pending=await meta().get('pending/'+id,{type:'json',consistency:'strong'});
 if(!pending)return fail('업로드를 찾을 수 없습니다.',404);
 if(Date.now()-new Date(pending.created_at).getTime()>30*60000)return fail('업로드 시간이 초과됐습니다.',410);
 const media=files();
 const chunks=await Promise.all(Array.from({length:pending.parts},(_,i)=>media.get(`chunks/${id}/${String(i).padStart(3,'0')}`,{type:'arrayBuffer',consistency:'strong'})));
 if(chunks.some(c=>!c))return fail('업로드가 완료되지 않았습니다. 다시 시도해 주세요.',409);
 if(chunks.reduce((n,c)=>n+c.byteLength,0)!==pending.size)return fail('파일 크기 검증에 실패했습니다.',409);
 const doc={id,class_number:pending.class_number,mime_type:pending.mime_type,media_path:id,caption:pending.caption,created_at:pending.created_at,size:pending.size,parts:pending.parts};
 // Distinct story keys avoid read-modify-write races between different students.
 await meta().setJSON('stories/'+id,doc,{onlyIfNew:true});
 await meta().delete('pending/'+id);
 return json({ok:true,id});
}
async function getMedia(req,url){
 const id=url.searchParams.get('id');if(!validId(id))return fail('파일을 찾을 수 없습니다.',404);
 const p=await validStory(id);if(!p)return fail('삭제되었거나 존재하지 않는 파일입니다.',404);
 const total=p.size, range=req.headers.get('range')||'';
 let start=0,end=total-1,status=200;
 if(range){const match=/^bytes=(\d*)-(\d*)$/.exec(range);if(!match)return new Response(null,{status:416,headers:{'Content-Range':`bytes */${total}`}});start=match[1]?Number(match[1]):Math.max(0,total-Number(match[2]||0));end=match[2]&&match[1]?Math.min(total-1,Number(match[2])):total-1;if(start<0||start>=total||end<start)return new Response(null,{status:416,headers:{'Content-Range':`bytes */${total}`}});status=206;}
 const media=files();
 const stream=new ReadableStream({async start(ctrl){try{const first=Math.floor(start/PART_SIZE),last=Math.floor(end/PART_SIZE);for(let i=first;i<=last;i++){const buf=await media.get(`chunks/${id}/${String(i).padStart(3,'0')}`,{type:'arrayBuffer',consistency:'strong'});if(!buf)throw Error('missing media chunk');const slice=new Uint8Array(buf).subarray(i===first?start%PART_SIZE:0,i===last?(end%PART_SIZE)+1:undefined);ctrl.enqueue(slice)}ctrl.close()}catch(e){ctrl.error(e)}}});
 const headers={'Content-Type':p.mime_type,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Accept-Ranges':'bytes','Content-Length':String(end-start+1),'Content-Disposition':'inline'};
 if(status===206)headers['Content-Range']=`bytes ${start}-${end}/${total}`;
 if(req.method==='HEAD')return new Response(null,{status,headers});
 return new Response(stream,{status,headers});
}
async function likes(req){const data=await readJSON(req),id=data.id,device=data.device;
 if(!validId(id)||!validDevice(device))return fail('잘못된 요청입니다.');if(!await validStory(id))return fail('삭제된 스토리입니다.',404);
 const store=social(),key=`likes/${id}/${hash(device)}`;let liked;
 if(data.liked===true){await store.set(key,'1');liked=true}else if(data.liked===false){await store.delete(key);liked=false}else return fail('좋아요 값이 잘못됐습니다.');
 const like_count=await countPrefix(store,`likes/${id}/`);return json({ok:true,liked,like_count});}
async function report(req){const data=await readJSON(req),id=data.id,device=data.device;
 if(!validId(id)||!validDevice(device))return fail('잘못된 요청입니다.');if(!await validStory(id))return fail('삭제된 스토리입니다.',404);
 const store=social(),key=`reports/${id}/${hash(device)}`;
 if(await store.get(key,{consistency:'strong'}))return fail('이미 신고한 스토리입니다.',409);
 await store.setJSON(key,{story_id:id,reason:'부적절한 콘텐츠',created_at:new Date().toISOString()});return json({ok:true});}
async function login(req){if(!adminReady())return fail('운영자 계정이 아직 설정되지 않았습니다. Netlify 환경 변수를 확인해 주세요.',503);
 const data=await readJSON(req),{email,password,secret}=secrets(),em=String(data.email||'').trim().toLowerCase(),pw=String(data.password||'');
 const ipHash=hash(getIp(req)).slice(0,28),win=Math.floor(Date.now()/(15*60000)),store=social(),prefix=`login-failed/${win}/${ipHash}/`;
 if(await countPrefix(store,prefix)>=6)return fail('로그인 시도가 너무 많습니다. 15분 뒤 다시 시도하세요.',429);
 const okay=same(hash(pw),hash(password))&&same(em,email);
 if(!okay){await store.set(prefix+randomUUID(),'1');return fail('관리자 계정 또는 비밀번호가 올바르지 않습니다.',401)}
 return json({token:generateToken('admin',8*3600,secret)});
}
async function adminList(){const store=social(),entries=(await store.list({prefix:'reports/'})).blobs;
 const reports=(await Promise.all(entries.slice(0,1000).map(e=>store.get(e.key,{type:'json',consistency:'strong'})))).filter(Boolean);
 return json(reports.slice(0,300));}
async function deletePost(req){const data=await readJSON(req),id=data.id;if(!validId(id))return fail('잘못된 스토리 ID입니다.');
 const p=await validStory(id);if(!p)return fail('이미 삭제한 스토리입니다.',404);
 // Remove the story record first so further media reads immediately fail.
 await meta().delete('stories/'+id);
 const media=files();await Promise.all(Array.from({length:p.parts},(_,i)=>media.delete(`chunks/${id}/${String(i).padStart(3,'0')}`)));
 const act=social();for(const type of ['likes','reports']){const keys=(await act.list({prefix:`${type}/${id}/`})).blobs;await Promise.all(keys.map(x=>act.delete(x.key)));}
 return json({ok:true});}

export default async function handler(req){
 const url=new URL(req.url),action=url.searchParams.get('action')||'', method=req.method;
 try{
  if(action==='ready'&&method==='GET')return json({ok:secretUpload().length>=32,storage:'Netlify Blobs',adminConfigured:adminReady(),videoMaxSeconds:10,videoMaxBytes:MAX_VIDEO});
  if(action==='list'&&method==='GET')return feed(url);
  if(action==='media'&&['GET','HEAD'].includes(method))return getMedia(req,url);
  if(action==='start'&&method==='POST')return start(req);
  if(action==='part'&&method==='POST')return part(req,url);
  if(action==='finish'&&method==='POST')return finish(req);
  if(action==='like'&&method==='POST')return likes(req);
  if(action==='report'&&method==='POST')return report(req);
  if(action==='login'&&method==='POST')return login(req);
  if(['admin-list','delete'].includes(action)){if(!adminAuthed(req))return fail('관리자 인증이 필요합니다.',401);if(action==='admin-list'&&method==='GET')return adminList();if(action==='delete'&&method==='POST')return deletePost(req);}
  return fail('요청 경로를 찾을 수 없습니다.',404);
 }catch(e){console.error('VLOG API:',action,e);return fail('서버 요청에 실패했습니다. 잠시 후 다시 시도하세요.',500);}
}
